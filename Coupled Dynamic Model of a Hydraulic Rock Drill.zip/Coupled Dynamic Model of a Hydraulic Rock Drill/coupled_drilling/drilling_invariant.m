function a = drilling_invariant(z)
% Translation-invariant Poincare state. Retains rock indentation/history
% relative to the mechanism, and ABSOLUTE velocities (not just differences).
z=z(:);
a=[z(1)-z(7);z(2);z(3)-z(7);z(4);z(5)-z(23);z(6); ...
    z(7)-z(23);z(8);z(9:22);z(24)];
end
