function [dz,out] = drilling_rhs(~,z,p,bufferEmpty)
% DRILLING_RHS SI autonomous 24-state coupled dynamics.
% z=[Xp,Vp,Xt,Vt,Xb,Vb,Xc,Vc,xvRelative,vvRelative,p1..p12,r,pFeed].
% The case receives every internal mechanical reaction. Feed acts on the bit
% only, from an actuator supported outside the modeled moving case.
% Numerical floors below are finite RHS continuations for solver trial states;
% algebraic events stop invalid accepted states. Ordinary pressure is never clipped.
pos=[z(1)-z(7);z(3)-z(7);z(9)]; vel=[z(2)-z(8);z(4)-z(8);z(10)];
P=z(11:22); pp=[0;P]; de=pp(p.ab(:,1)+1)-pp(p.ab(:,2)+1);
Q=zeros(19,1); ip=[1 6 7 13 17]; io=[2 3 4 5 8 9 10 11 14 16];
Q(ip)=pipeFlow(de(ip),p);
s=[pos(3)-p.L3;p.L3r-pos(3);p.L4-pos(3);pos(3)-p.L4r; ...
    p.xPilotLow-pos(1);pos(1)-p.xPilotHigh;pos(1)-p.xPilotHigh;p.xPilotLow-pos(1); ...
    pos(2)-p.L9;pos(2)-p.L910];
area=pi*[.03*ones(4,1);.044*ones(4,1);.08;.076].*min(max(s,0),p.maxOpening);
Q(io)=p.Cd*sqrt(2/p.rho)*area.*de(io)./(de(io).^2+p.dpSmooth^2).^.25;
Q(12)=p.reliefG(1)*max(P(1)-p.reliefPressure(1),0);
Q(15)=pipeFlow(max(de(15),0),p); % supply -> stage 2 check valve
Q(18)=p.reliefG(2)*max(P(12)-p.reliefPressure(2),0);
Q(19)=p.Gleak*de(19);
if bufferEmpty, Q(17)=0; end % physical empty-accumulator poppet mode
V=p.V0+p.B*pos; C=max(V,p.minVolume)/p.beta;
pg=max(P(p.acc)+p.patm,1); Vg=p.Vg0.*((p.precharge+p.patm)./pg).^(1/p.nGas);
C(p.acc)=Vg./(p.nGas*pg);
makeup=p.makeupG*max(-P-p.makeupCrack,0); makeup(p.acc)=0;
dP=(p.S*Q+p.source+makeup-p.B*vel)./C;
if bufferEmpty, dP(11)=0; end
Fh=p.B'*P;
Fp=Fh(1)-p.cPiston*vel(1);
Ft=Fh(2)-p.cTool*vel(2)-p.kMount*(pos(2)-p.mountRest);
Fv=Fh(3)-p.cValve*vel(3);
Fstop=0;
if pos(3)<p.valveLow
    Fstop=-p.kStop*(pos(3)-p.valveLow)-p.cStop*min(vel(3),0);
elseif pos(3)>p.valveHigh
    Fstop=-p.kStop*(pos(3)-p.valveHigh)-p.cStop*max(vel(3),0);
end
Fv=Fv+Fstop;
Frod=p.kRod*(z(3)-z(5)-p.rodRest)+p.cRod*(z(4)-z(6));
delta=max(z(5)-z(23),0);
Frock=p.kUref*p.deltaRef/p.rockExponent*(delta/p.deltaRef)^p.rockExponent;
alpha=p.kLref/p.kUref;
dr=0; if delta>0, dr=(1-alpha)*max(z(6),0); end
Ffeed=p.Afeed*z(24); ac=(-Fp-Ft-Fv)/p.mCase;
dz=[z(2);Fp/p.mPiston;z(4);(Ft-Frod)/p.mTool;z(6); ...
    (Frod+Ffeed-Frock)/p.mBit;z(8);ac;z(10);Fv/p.mValve-ac;dP;dr; ...
    (p.Gfeed*(p.feedSetPressure-z(24))-p.Afeed*z(6))/p.Cfeed];
if nargout>1
    out.xpRel=pos(1); out.xtRel=pos(2); out.delta=delta;
    out.Frock=Frock; out.Ffeed=Ffeed; out.Frod=Frod; out.Fstop=Fstop;
    out.KLtan=p.kLref*(delta/p.deltaRef)^(p.rockExponent-1);
    out.KUtan=p.kUref*(delta/p.deltaRef)^(p.rockExponent-1);
    out.contactMode=0; out.activeTangent=0;
    if delta>0
        if z(6)>=0, out.contactMode=1; out.activeTangent=out.KLtan;
        else, out.contactMode=-1; out.activeTangent=out.KUtan;
        end
    end
    out.rockRate=dr; out.rockDissipation=Frock*dr;
    out.V=V; out.Vg=Vg; out.q=Q; out.makeup=makeup;
    out.totalMomentum=p.mPiston*z(2)+p.mTool*z(4)+p.mBit*z(6)+ ...
        p.mCase*z(8)+p.mValve*(z(8)+z(10));
    out.momentumResidual=p.mPiston*dz(2)+p.mTool*dz(4)+p.mBit*dz(6)+ ...
        p.mCase*dz(8)+p.mValve*(dz(8)+dz(10))-Ffeed+Frock;
end
end

function q=pipeFlow(dp,p)
q=2*dp./(p.Rpipe+sqrt(p.Rpipe^2+4*p.Kpipe*abs(dp)));
end
