function [value,isterminal,direction] = drilling_events(~,y,p,bufferEmpty)
% Algebraic events; no RHS calls or hidden coordinate/pressure projections.
z=y(:).*p.stateScale; P=z(11:22);
pos=[z(1)-z(7);z(3)-z(7);z(9)]; V=p.V0+p.B*pos;
hit=z(1)-z(3)-p.collisionGap;
% Ignore the exact contact root while bodies are separating after restitution.
if z(2)<=z(4), hit=min(hit,-1e-12); end
if bufferEmpty
    bufferSwitch=P(9)-p.precharge(2); switchDirection=1;
else
    bufferSwitch=P(11)-p.precharge(2); switchDirection=-1;
    % At refill, a nonnegative charging pressure gradient cannot empty it.
    if P(9)>=P(11), bufferSwitch=max(bufferSwitch,1e-6); end
end
value=[hit;min(V(p.ordinary))-p.minVolume; ...
    min([P;z(24)]+p.patm)-p.minAbsPressure;P(2)-p.precharge(1); ...
    pos(1)-p.minPistonRel;bufferSwitch];
isterminal=ones(6,1); direction=[1;-1;-1;-1;-1;switchDirection];
end
