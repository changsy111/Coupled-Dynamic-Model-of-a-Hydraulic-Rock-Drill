function d = drilling_derive(t,z,p,mode)
% SI quantities sampled along accepted states, including mode discontinuities.
n=numel(t); keys={'xpRel','xtRel','delta','Frock','Ffeed','Frod','KLtan','KUtan', ...
    'rockRate','rockDissipation','totalMomentum','momentumResidual','contactMode','activeTangent'};
for j=1:numel(keys), d.(keys{j})=zeros(n,1); end
d.minimumVolume=zeros(n,1); d.minimumAbsolutePressure=zeros(n,1);
d.makeupFlow=zeros(n,1); d.stopPenetration=zeros(n,1);
for i=1:n
    [~,a]=drilling_rhs(t(i),z(i,:)',p,logical(mode(i)));
    for j=1:numel(keys), d.(keys{j})(i)=a.(keys{j}); end
    d.minimumVolume(i)=min(a.V(p.ordinary));
    d.minimumAbsolutePressure(i)=min([z(i,11:22) z(i,24)]+p.patm);
    d.makeupFlow(i)=sum(a.makeup);
    d.stopPenetration(i)=max([p.valveLow-z(i,9),z(i,9)-p.valveHigh,0]);
end
if n>0
    d.bitAdvance=z(:,5)-z(1,5); d.rockAdvance=z(:,23)-z(1,23);
else
    d.bitAdvance=zeros(0,1); d.rockAdvance=zeros(0,1);
end
end
