function p = drilling_parameters()
% DRILLING_PARAMETERS Autonomous impact / dual-buffer / advancing-rock model.
% SI units; pressures are gauge Pa. Assumed research geometry, NOT an
% identified Epiroc COP 1838 model. See README for provenance/limitations.
p.rho=850; p.mu=.03893; p.beta=1.4e9; p.Cd=.6; p.patm=101325; p.nGas=1.4;
p.mPiston=5; p.mTool=36.86; p.mBit=1; p.mCase=200; p.mValve=.389;
p.cPiston=70; p.cTool=9000; p.cValve=1500;
p.rodE=210e9; p.rodDo=.040; p.rodDi=.012; p.rodLength=3.63;
p.kRod=p.rodE*pi*(p.rodDo^2-p.rodDi^2)/(4*p.rodLength); p.cRod=2450;
p.kMount=9e5; p.mountPreload=15000;
p.A1=pi/4*(.044^2-.037^2); p.A2=pi/4*(.044^2-.041^2);
p.Apilot=pi/4*.013^2; p.Amain=pi/4*(.0145^2-.013^2);
p.Ad1=pi/4*(.080^2-.076^2); p.Ad2=pi/4*(.076^2-.070^2);
p.AvNominal=pi/4*(.030^2-.015^2);
% Columns: piston/case, tool/case, valve/case displacement. Force=B'*P.
p.B=zeros(12,3); p.B(3,3)=-p.Amain; p.B(4,3)=p.Amain;
p.B(5,1)=p.A1; p.B(6,1)=-p.A2;
p.B(7,3)=p.Apilot; p.B(8,3)=-p.Apilot;
p.B(9,2)=p.Ad1; p.B(10,2)=p.Ad2;
p.V0=[p.AvNominal*.0126;0;p.AvNominal*.0274;p.AvNominal*.0274; ...
    p.A1*.0317;p.A2*.0638;p.Apilot*.0106;p.Apilot*.005; ...
    p.Ad1*.019;p.Ad2*.0018;0;.0003];
p.ordinary=[1 3 4 5 6 7 8 9 10 12]; p.acc=[2 11];
p.precharge=[9e6;9e6]; p.Vg0=[.0004;.0003];
p.ab=[1 2;1 3;3 0;1 4;4 0;3 5;6 4;1 7;7 0;1 8;8 0;1 0; ...
    12 9;9 0;12 10;9 10;9 11;12 0;10 9];
p.S=zeros(12,19);
for j=1:19
    p.S(p.ab(j,1),j)=-1;
    if p.ab(j,2)>0, p.S(p.ab(j,2),j)=1; end
end
p.source=zeros(12,1); p.source(1)=90/60000; p.source(12)=15/60000;
p.Rpipe=128*p.mu*.1/(pi*.01^4);
p.Kpipe=.03*.1/.01*p.rho/(2*(pi*.01^2/4)^2);
p.leakClearance=100e-6; % assumed effective bypass clearance; original 17 um traps stage-2 pressure
p.Gleak=pi*.076*p.leakClearance^3/(12*p.mu*.01);
p.reliefPressure=[21e6;7e6]; p.reliefG=[p.source(1);p.source(12)]/.5e6;
p.makeupG=1e-7; p.makeupCrack=50000; p.dpSmooth=1000; p.maxOpening=.003;
p.xPilotLow=.011; p.xPilotHigh=.030; p.L3=.0031; p.L3r=.0025;
p.L4=.0025; p.L4r=.0031; p.L9=.0047; p.L910=.0068;
p.valveLow=.001; p.valveHigh=.0046; p.kStop=2e8; p.cStop=1500;
p.initialToolRel=.004706485; p.collisionGap=.035-p.initialToolRel;
p.mountRest=p.initialToolRel-p.mountPreload/p.kMount;
p.rodRest=p.initialToolRel; % generalized axial displacements use separate origins
p.restitution=.3;
p.kLref=4.91e11; p.kUref=7.51e11; p.rockExponent=2;
p.deltaRef=.001; p.alpha=p.kLref/p.kUref;
p.Afeed=.001; p.feedSetPressure=5e6; p.Cfeed=.002/p.beta; p.Gfeed=5e-9;
p.minAbsPressure=2000; p.minVolume=1e-9; p.minPistonRel=-.020;
p.minImpactSpeed=.05; p.minImpactPeriod=.001; p.minCycleAdvance=1e-9;
p.advanceResidualFloor=1e-7;
p.stateScale=[.04;10;.04;5;.04;5;.04;5;.006;5;20e6*ones(12,1);.04;5e6];
p.invariantScale=[.04;10;.006;5;.001;5;.04;5;.006;5;20e6*ones(12,1);5e6];
delta0=p.deltaRef*(p.rockExponent*p.Afeed*p.feedSetPressure/(p.kUref*p.deltaRef))^(1/p.rockExponent);
P=[18;18;.5;18;.5;18;18;.5;10;10;10;10]*1e6;
p.initialStateSI=[.026;-.1;p.initialToolRel;0;0;0;0;0;.001;0;P;-delta0;p.feedSetPressure];
p.initialBufferEmpty=false;
end
