function result = drilling_system_3s_fast(options)
% Simulate 0 to 3 s and plot the full interval; steady state is not required.
% Usage: result = drilling_system_3s_fast;
% Requires the original drilling_parameters, drilling_rhs, drilling_events,
% drilling_invariant, drilling_derive, and drilling_plot_results functions.
% The 3 s limit is simulation time, not wall time. Domain events or solver failure can stop integration early.
% This version enforces MaxTime=3, StopWhenSteady=false, MakePlots=true, and DiscardTime=0.
% Solver accuracy, collision handling, and governing equations are unchanged.
% Accumulate trajectory segments. Large time-series CSV export is disabled by default; the MAT file retains the full trajectory.
% Save uncompressed v7.3 MAT files to avoid compression overhead at the cost of disk space.
% Enable time-series CSV export: drilling_system_3s_fast(struct('SaveTimeseriesCSV',true))
if nargin<1, options=struct(); end
assert(isstruct(options)&&isscalar(options),'options must be a scalar struct.');
here=fileparts(mfilename('fullpath'));
o=struct('MaxTime',3,'MaxImpacts',100000,'MinImpacts',30,'SteadyTolerance',1e-3, ...
    'ConsecutiveCycles',10,'ConfirmationCycles',10,'RelTol',2e-7, ...
    'AbsTolSI',[repmat([1e-8;1e-6],5,1);10*ones(12,1);1e-8;10], ...
    'MaxStep',2.5e-5,'InitialStateSI',[],'InitialBufferEmpty',[], ...
    'Parameters',[],'MakePlots',true,'SaveResults',true,'SaveTimeseriesCSV',false, ...
    'StopWhenSteady',false,'DiscardTime',0, ...
    'OutputDirectory',fullfile(here,'results_3s_fast'));
fn=fieldnames(options);
for j=1:numel(fn)
    assert(isfield(o,fn{j}),['Unknown option: ' fn{j}]); o.(fn{j})=options.(fn{j});
end
% Use a fixed 3 s interval without waiting for steady state or discarding the first 2 s.
o.MaxTime=3;o.StopWhenSteady=false;o.DiscardTime=0;o.MakePlots=true;
fprintf('开始计算0~3秒仿真；结束后自动绘图。3秒为仿真时间，不是实际计算耗时。\n');
wallTimer=tic;
if isempty(o.Parameters), p=drilling_parameters(); else, p=o.Parameters; end
p.alpha=p.kLref/p.kUref; % keep constitutive ratio consistent after parameter edits
validateattributes(o.MaxTime,{'numeric'},{'scalar','finite','positive'});
validateattributes(o.DiscardTime,{'numeric'},{'scalar','finite','nonnegative'});
assert(o.DiscardTime<o.MaxTime,'DiscardTime must be less than MaxTime.');
assert(isscalar(o.StopWhenSteady)&&ismember(o.StopWhenSteady,[0 1]), ...
    'StopWhenSteady must be logical.');
validateattributes(o.MaxStep,{'numeric'},{'scalar','finite','positive'});
validateattributes(o.RelTol,{'numeric'},{'scalar','finite','positive'});
validateattributes(o.SteadyTolerance,{'numeric'},{'scalar','finite','positive'});
validateattributes(o.MaxImpacts,{'numeric'},{'scalar','integer','positive'});
validateattributes(o.MinImpacts,{'numeric'},{'scalar','integer','>=',3});
validateattributes(o.ConsecutiveCycles,{'numeric'},{'scalar','integer','positive'});
validateattributes(o.ConfirmationCycles,{'numeric'},{'scalar','integer','positive'});
scale=p.stateScale(:); atol=o.AbsTolSI(:);
if isscalar(atol), atol=repmat(atol,24,1); end
assert(numel(scale)==24&&all(scale>0)&&all(isfinite(scale)),'Invalid state scale.');
assert(numel(atol)==24&&all(atol>0)&&all(isfinite(atol)),'AbsTolSI requires 24 positive finite values.');
assert(numel(p.invariantScale)==23&&all(p.invariantScale>0),'Invalid invariant scale.');
assert(p.alpha>0&&p.alpha<1&&p.rockExponent>1,'Rock law requires 0 < KL/KU < 1 and exponent > 1.');
assert(p.restitution>=0&&p.restitution<=1,'Restitution must lie in [0,1].');
assert(isequal(size(p.B),[12 3])&&isequal(size(p.S),[12 19]),'Invalid hydraulic matrices.');
if isempty(o.InitialStateSI), z=p.initialStateSI(:); else, z=o.InitialStateSI(:); end
assert(numel(z)==24&&all(isfinite(z)),'InitialStateSI requires 24 finite SI values.');
if isempty(o.InitialBufferEmpty), bufferEmpty=p.initialBufferEmpty; else, bufferEmpty=o.InitialBufferEmpty; end
assert(isscalar(bufferEmpty)&&(bufferEmpty==0||bufferEmpty==1),'InitialBufferEmpty must be logical.');
bufferEmpty=logical(bufferEmpty);

tNow=0; T=zeros(0,1); Z=zeros(0,24); modes=zeros(0,1);
% Store solver segments and concatenate once at the end to avoid copying the full history after each collision.
tParts=cell(0,1);zParts=cell(0,1);modeParts=cell(0,1);
partCount=0;lastTime=NaN;lastState=[];lastMode=NaN;
hits=zeros(0,1); pre=zeros(0,24); hitModes=zeros(0,1); rows=[]; switches=zeros(0,2);
passCount=0; confirmation=0; candidate=false; candidateImpact=NaN;
previousSwitchCount=0;
status='time_limit_not_steady'; message='Time limit reached before confirmed relative periodic drilling.';
converged=false; terminationEvent=0; mu=p.mPiston*p.mTool/(p.mPiston+p.mTool);
margin=domainMargins(z,p);
badEmpty=bufferEmpty&&abs(z(21)-p.precharge(2))>1e-3;
if any(margin<0)||z(1)-z(3)>p.collisionGap+1e-10||z(21)<p.precharge(2)-1e-3||badEmpty
    status='invalid_initial_state'; message='Initial state violates a physical domain or empty-accumulator condition.';
    T=0; Z=z'; modes=double(bufferEmpty);
else
    while tNow<o.MaxTime&&numel(hits)<o.MaxImpacts
        tStart=tNow;
        solverOptions=odeset('RelTol',o.RelTol,'AbsTol',atol./scale,'MaxStep',o.MaxStep, ...
            'Events',@(t,y)drilling_events(t,y,p,bufferEmpty));
        try
            [tt,yy,te,ye,ie]=ode15s(@(t,y)drilling_rhs(t,y.*scale,p,bufferEmpty)./scale, ...
                [tNow o.MaxTime],z./scale,solverOptions);
        catch ME
            status='solver_failure'; message=ME.message; break
        end
        zz=bsxfun(@times,yy,scale'); first=1;
        if partCount>0 && tt(1)==lastTime && all(zz(1,:)==lastState) && lastMode==bufferEmpty,first=2;end
        if first<=numel(tt)
            partCount=partCount+1;
            tParts{partCount,1}=tt(first:end);zParts{partCount,1}=zz(first:end,:);
            modeParts{partCount,1}=repmat(double(bufferEmpty),numel(tt)-first+1,1);
            lastTime=tt(end);lastState=zz(end,:);lastMode=double(bufferEmpty);
        end
        tNow=tt(end); z=zz(end,:)';
        if isempty(ie)
            if tNow<o.MaxTime-100*eps(max(1,o.MaxTime))
                status='solver_incomplete'; message='ode15s stopped without reaching a terminal event or final time.';
            end
            break
        end
        tEvent=te(end); active=ie(abs(te-tEvent)<=100*eps(max(1,tEvent)));
        z=ye(end,:)'.*scale; tNow=tEvent;
        domain=active(active>=2&active<=5);
        if ~isempty(domain)
            terminationEvent=domain(end); status='domain_boundary';
            descriptions={'collision','minimum chamber volume','minimum absolute pressure', ...
                'empty impact accumulator','minimum relative piston position','buffer accumulator mode'};
            message=['Stopped at domain boundary: ' descriptions{terminationEvent} '.']; break
        end
        if any(active==6)
            if tNow-tStart<1e-12&&~isempty(switches)&&abs(tNow-switches(end,1))<1e-10
                status='accumulator_mode_chatter'; message='Repeated zero-time buffer mode transition; integration stopped.'; break
            end
            bufferEmpty=~bufferEmpty;
            z(21)=p.precharge(2); % exact physical empty/refill boundary, not a pressure clamp
            switches(end+1,:)=[tNow,double(bufferEmpty)]; %#ok<AGROW>
            partCount=partCount+1;tParts{partCount,1}=tNow;zParts{partCount,1}=z';
            modeParts{partCount,1}=double(bufferEmpty);
            lastTime=tNow;lastState=z';lastMode=double(bufferEmpty);
        end
        if ~any(active==1), continue; end
        vr=z(2)-z(4); n=numel(hits)+1;
        hits(n,1)=tNow; pre(n,:)=z'; hitModes(n,1)=double(bufferEmpty); %#ok<AGROW>
        cycleSwitchCount=size(switches,1)-previousSwitchCount;
        previousSwitchCount=size(switches,1);
        energy=.5*mu*vr^2; loss=(1-p.restitution^2)*energy;
        period=NaN; frequency=NaN; er=NaN; sr=NaN; tr=NaN; da=NaN; dr=NaN; ar=NaN;
        if n>=2
            period=hits(n)-hits(n-1); frequency=1/period;
            a=drilling_invariant(z); b=drilling_invariant(pre(n-1,:)');
            sr=max(abs((a-b)./p.invariantScale));
            oldEnergy=.5*mu*(pre(n-1,2)-pre(n-1,4))^2;
            er=abs(energy-oldEnergy)/max(abs(oldEnergy),eps);
            da=z(5)-pre(n-1,5); dr=z(23)-pre(n-1,23);
        end
        if n>=3
            oldPeriod=hits(n-1)-hits(n-2); tr=abs(period-oldPeriod)/max(abs(oldPeriod),eps);
            oldDa=pre(n-1,5)-pre(n-2,5); oldDr=pre(n-1,23)-pre(n-2,23);
            ar=max([abs(da-oldDa)/max(abs(oldDa),p.advanceResidualFloor), ...
                abs(dr-oldDr)/max(abs(oldDr),p.advanceResidualFloor)]);
        end
        passed=n>o.MinImpacts&&da>p.minCycleAdvance&&dr>p.minCycleAdvance&& ...
            hitModes(n)==hitModes(n-1)&&cycleSwitchCount==rows(n-1,18)&& ...
            max([sr,tr,er,ar])<o.SteadyTolerance;
        if passed
            passCount=passCount+1;
            if candidate, confirmation=confirmation+1;
            elseif passCount>=o.ConsecutiveCycles, candidate=true; candidateImpact=n; confirmation=0;
            end
        else
            passCount=0; confirmation=0; candidate=false; candidateImpact=NaN;
        end
        rows(n,:)=[n,tNow,period,frequency,vr,energy,loss,sr,tr,er,da,dr,ar, ...
            double(passed),passCount,confirmation,double(bufferEmpty),cycleSwitchCount]; %#ok<AGROW>
        if vr<p.minImpactSpeed
            status='low_speed_contact'; message='Low-speed contact requires a sticking/contact mode; no artificial bounce was applied.'; break
        end
        if n>=2&&period<p.minImpactPeriod
            status='microimpact'; message='Micro-collision sequence requires a sticking/contact mode; it is not accepted as steady drilling.'; break
        end
        % Exact two-mass collision conserves momentum. Case, bit, valve and
        % hydraulic states are continuous across the finite impulse.
        J=(1+p.restitution)*mu*vr; z(2)=z(2)-J/p.mPiston; z(4)=z(4)+J/p.mTool;
        partCount=partCount+1;tParts{partCount,1}=tNow;zParts{partCount,1}=z';
            modeParts{partCount,1}=double(bufferEmpty);
            lastTime=tNow;lastState=z';lastMode=double(bufferEmpty);
        if o.StopWhenSteady&&candidate&&confirmation>=o.ConfirmationCycles
            converged=true; status='relative_period_1';
            message='Full relative state, period, relative impact energy and positive cycle advance passed confirmation.'; break
        end
        if mod(n,10)==0
            fprintf('Impact %d, t=%.5f s, f=%.3f Hz, state residual=%.3g, advance=%.6f mm/cycle\n', ...
                n,tNow,frequency,sr,da*1e3);
        end
    end
    if ~converged&&numel(hits)>=o.MaxImpacts&&strcmp(status,'time_limit_not_steady')
        status='impact_limit_not_steady'; message='Impact limit reached without confirmed relative convergence.';
    end
end
if ~o.StopWhenSteady && strcmp(status,'time_limit_not_steady') && ...
        tNow>=o.MaxTime-100*eps(max(1,o.MaxTime))
    status='fixed_time_complete';
    message='Completed 0..3 s simulation; plotting the full interval. Steady state is not certified.';
end
if partCount>0
    T=vertcat(tParts{:});clear tParts;
    Z=vertcat(zParts{:});clear zParts;
    modes=vertcat(modeParts{:});clear modeParts;
end
names={'impact','timeS','periodS','frequencyHz','relativeVelocityMS','relativeEnergyJ', ...
    'collisionLossJ','stateResidual','periodResidual','energyResidual','bitAdvanceM', ...
    'rockAdvanceM','advanceResidual','passed','consecutivePasses','confirmationCycles','bufferEmpty', ...
    'bufferSwitchesThisCycle'};
if isempty(rows), rows=zeros(0,numel(names)); end
cycleMetrics=array2table(rows,'VariableNames',names);
derived=drilling_derive(T,Z,p,modes); summary=makeSummary(T,Z,rows,derived,switches);
result=struct('status',status,'converged',converged,'message',message,'t',T,'zSI',Z, ...
    'bufferEmpty',logical(modes),'impactTime',hits,'preImpactStateSI',pre, ...
    'preImpactBufferEmpty',logical(hitModes),'bufferModeTransitions',switches, ...
    'cycleMetrics',cycleMetrics,'derived',derived,'summary',summary,'parameters',p,'options',o, ...
    'candidateImpact',candidateImpact,'terminationEvent',terminationEvent, ...
    'finalStateSI',z,'finalBufferEmpty',bufferEmpty,'outputFiles',{{}});
fprintf('\nStatus: %s\n%s\n',status,message);
fprintf('Impacts: %d; f=%.6f Hz; relative impact energy=%.6f J; penetration=%.6f mm/s.\n', ...
    summary.impactCount,summary.frequencyHz,summary.meanRelativeEnergyJ,summary.penetrationRateMS*1e3);
fprintf('仿真实际到达%.6f秒，计算耗时%.1f秒，准备绘图。\n',tNow,toc(wallTimer));
if tNow<o.MaxTime-100*eps(max(1,o.MaxTime))
    warning('Drilling:EarlyStop','仿真提前结束于%.6f秒：%s。将绘制已得到的有效结果，不补造剩余数据。',tNow,message);
end
figs=gobjects(0);
if o.MakePlots
    figs=drilling_plot_results(result);
    drawnow;
end
if o.SaveResults
    if ~exist(o.OutputDirectory,'dir'), [ok,msg]=mkdir(o.OutputDirectory); assert(ok,msg); end
    csv=fullfile(o.OutputDirectory,'drilling_cycle_metrics.csv');
    series=fullfile(o.OutputDirectory,'drilling_timeseries.csv');
    mat=fullfile(o.OutputDirectory,'drilling_steady_result.mat');
    writetable(cycleMetrics,csv);
    result.outputFiles={csv,mat};
    if o.SaveTimeseriesCSV
        writetable(makeTimeseries(result),series);
        result.outputFiles{end+1}=series;
    end
    for j=1:numel(figs)
        name=fullfile(o.OutputDirectory,sprintf('drilling_figure_%02d.png',j));
        print(figs(j),name,'-dpng','-r160'); result.outputFiles{end+1}=name;
    end
    save(mat,'result','-v7.3','-nocompression');
end
end

function m=domainMargins(z,p)
P=z(11:22); V=p.V0+p.B*[z(1)-z(7);z(3)-z(7);z(9)];
m=[min(V(p.ordinary))-p.minVolume;min([P;z(24)]+p.patm)-p.minAbsPressure; ...
    P(2)-p.precharge(1);z(1)-z(7)-p.minPistonRel];
end

function s=makeSummary(t,z,rows,d,switches)
s=struct('impactCount',size(rows,1),'finalTimeS',0,'frequencyHz',NaN, ...
    'meanRelativeEnergyJ',NaN,'meanRelativeImpactVelocityMS',NaN,'penetrationRateMS',NaN, ...
    'rockAdvanceRateMS',NaN,'bitAdvanceM',NaN,'rockAdvanceM',NaN, ...
    'minimumAbsolutePressurePa',NaN,'minimumOrdinaryVolumeM3',NaN, ...
    'maxStopPenetrationM',NaN,'maxMomentumResidualN',NaN,'bufferModeSwitchCount',size(switches,1));
if ~isempty(t)
    s.finalTimeS=t(end); s.bitAdvanceM=z(end,5)-z(1,5); s.rockAdvanceM=z(end,23)-z(1,23);
    s.minimumAbsolutePressurePa=min(d.minimumAbsolutePressure); s.minimumOrdinaryVolumeM3=min(d.minimumVolume);
    s.maxStopPenetrationM=max(d.stopPenetration); s.maxMomentumResidualN=max(abs(d.momentumResidual));
end
if ~isempty(rows)
    k=max(2,size(rows,1)-9):size(rows,1);
    if ~isempty(k)
        s.frequencyHz=1/mean(rows(k,3)); s.meanRelativeEnergyJ=mean(rows(k,6));
        s.meanRelativeImpactVelocityMS=mean(rows(k,5));
        s.penetrationRateMS=sum(rows(k,11))/sum(rows(k,3)); s.rockAdvanceRateMS=sum(rows(k,12))/sum(rows(k,3));
    end
end
end

function tbl=makeTimeseries(r)
stateNames={'pistonPositionM','pistonVelocityMS','toolPositionM','toolVelocityMS', ...
    'bitPositionM','bitVelocityMS','casePositionM','caseVelocityMS','valveRelativePositionM', ...
    'valveRelativeVelocityMS','p1Pa','p2Pa','p3Pa','p4Pa','p5Pa','p6Pa','p7Pa','p8Pa', ...
    'p9Pa','p10Pa','p11Pa','p12Pa','rockFrontM','feedPressurePa'};
d=r.derived;
A=[r.t,r.zSI,double(r.bufferEmpty),d.xpRel,d.xtRel,d.delta,d.Frock,d.Ffeed, ...
    d.KLtan,d.KUtan,d.activeTangent,d.contactMode,d.rockRate,d.bitAdvance,d.rockAdvance,d.momentumResidual];
names=[{'timeS'},stateNames,{'bufferEmpty','pistonRelativeM','toolRelativeM','rockIndentationM', ...
    'rockForceN','feedForceN','loadingTangentNM','unloadingTangentNM','activeTangentNM','contactMode','rockRateMS', ...
    'bitAdvanceM','rockAdvanceM','momentumResidualN'}];
tbl=array2table(A,'VariableNames',names);
end
