function figs = drilling_plot_results(result)
% DRILLING_PLOT_RESULTS Coupled impact-buffer-feed-rock simulation figures.
% Uses the result schema documented in drilling_system_steady.m.
% All input states are SI; plot labels state the displayed engineering units.
% This plotting source was reviewed but not run in native MATLAB here.
% The force-displacement loop uses bit position from a FIXED cycle origin.
% Plotting force against elastic delta alone would remove the plastic drift
% and conceal the loading/unloading loop of this constitutive model.
figs=gobjects(0,1);
if ~isfield(result,'t') || ~isfield(result,'zSI') || isempty(result.t) || isempty(result.zSI)
    return
end
% Work on a local view only. Keep the original simulation/export unchanged.
fixedMode=isfield(result,'options') && isfield(result.options,'StopWhenSteady') ...
    && ~result.options.StopWhenSteady;
if fixedMode
    keep=result.t>=result.options.DiscardTime;
    if nnz(keep)<2
        warning('drilling:NoPlotWindow', ...
            'Simulation ended before a usable post-transient interval. Status: %s',result.status);
        return
    end
    nOriginal=numel(result.t);
    result.t=result.t(keep); result.zSI=result.zSI(keep,:);
    if isfield(result,'derived')
        keys=fieldnames(result.derived);
        for k=1:numel(keys)
            v=result.derived.(keys{k});
            if isvector(v)&&numel(v)==nOriginal, result.derived.(keys{k})=v(keep); end
        end
    end
    result.impactTime=result.impactTime(result.impactTime>=result.options.DiscardTime);
    result.cycleMetrics=result.cycleMetrics(result.cycleMetrics.timeS>=result.options.DiscardTime,:);
end
t=result.t(:); z=result.zSI;
assert(size(z,1)==numel(t) && size(z,2)>=24,'Expected an N-by-24 SI state matrix.');
if isfield(result,'derived'), d=result.derived; else, d=struct(); end
xpRel=getDerived('xpRel',z(:,1)-z(:,7));
xtRel=getDerived('xtRel',z(:,3)-z(:,7));
delta=getDerived('delta',max(z(:,5)-z(:,23),0));
Frock=getDerived('Frock',nan(size(t)));
Ffeed=getDerived('Ffeed',nan(size(t)));
KL=getDerived('KLtan',nan(size(t)));
KU=getDerived('KUtan',nan(size(t)));
rockRate=getDerived('rockRate',nan(size(t)));
bitAdvance=getDerived('bitAdvance',z(:,5)-z(1,5));
rockAdvance=getDerived('rockAdvance',z(:,23)-z(1,23));
if isfield(result,'impactTime'), hits=result.impactTime(:); else, hits=[]; end
if isfield(result,'cycleMetrics'), cycles=result.cycleMetrics; else, cycles=table(); end
status='unspecified';
if isfield(result,'status'), status=strrep(char(result.status),'_',' '); end
blue=[.08 .38 .58]; orange=[.84 .39 .13]; green=[.12 .51 .39];

if fixedMode
    figs(end+1,1)=traceFigure(true(size(t)),t(1),'Post-transient response (not certified steady)');
else
    startup=t<=min(t(end),t(1)+.2);
    figs(end+1,1)=traceFigure(startup,t(1),'Coupled drilling - startup');
end
if numel(hits)>=4
    windowStart=hits(end-3); windowTitle='Coupled drilling - final three impact cycles';
else
    windowStart=max(t(1),t(end)-.1); windowTitle='Coupled drilling - final available interval';
end
window=t>=windowStart;
if nnz(window)>=2
    figs(end+1,1)=traceFigure(window,windowStart,windowTitle);
end

f=figure('Color','w','Name','Impact, buffer and feed pressures','Position',[100 60 1100 820]);
figs(end+1,1)=f;
subplot(3,1,1); plot(t,z(:,11)/1e6,'Color',blue,'LineWidth',1);
grid on; ylabel('Impact inlet p1 (MPa gauge)'); title(['Calculated pressures | ' status]);
subplot(3,1,2); plot(t,z(:,19)/1e6,'Color',blue,'LineWidth',1); hold on;
plot(t,z(:,20)/1e6,'Color',orange,'LineWidth',1);
plot(t,z(:,22)/1e6,'Color',green,'LineWidth',1);
grid on; ylabel('Buffer pressure (MPa gauge)');
legend('p9: first chamber','p10: second chamber','p12: supply','Location','best');
subplot(3,1,3); plot(t,z(:,24)/1e6,'Color',blue,'LineWidth',1);
grid on; ylabel('Feed pressure pF (MPa gauge)'); xlabel('Time (s)');

if numel(hits)>=2, contactStart=hits(end-1); else, contactStart=windowStart; end
contact=t>=contactStart; first=find(contact,1,'first');
if ~isempty(first)
    tc=(t(contact)-contactStart)*1e3; xc=(z(contact,5)-z(first,23))*1e3;
    fc=Frock(contact)/1e3; dc=delta(contact)*1e3;
    loading=z(contact,6)>=0 & delta(contact)>0;
    unloading=z(contact,6)<0 & delta(contact)>0;
    fl=fc; fl(~loading)=NaN; fu=fc; fu(~unloading)=NaN;
    f=figure('Color','w','Name','Nonlinear bit-rock contact and stiffness','Position',[130 90 1120 780]);
    figs(end+1,1)=f;
    subplot(2,2,1); plot(xc,fl,'Color',blue,'LineWidth',1.4); hold on;
    plot(xc,fu,'Color',orange,'LineWidth',1.4);
    grid on; xlabel('Bit position from cycle rock origin (mm)'); ylabel('Rock force (kN)');
    title('Final-cycle loading / unloading path'); legend('Loading','Unloading','Location','best');
    subplot(2,2,2); plot(tc,KL(contact)/1e6,'Color',blue,'LineWidth',1.1); hold on;
    plot(tc,KU(contact)/1e6,'Color',orange,'LineWidth',1.1);
    grid on; xlabel('Time from cycle start (ms)'); ylabel('Tangent stiffness (MN/m)');
    title('Potential contact branch tangents'); legend('Loading tangent','Unloading tangent','Location','best');
    subplot(2,2,3); plot(tc,Frock(contact)/1e3,'Color',blue,'LineWidth',1.1); hold on;
    plot(tc,Ffeed(contact)/1e3,'Color',green,'LineWidth',1.1);
    grid on; xlabel('Time from cycle start (ms)'); ylabel('Force on bit (kN)');
    legend('Rock reaction magnitude','Forward feed force','Location','best');
    subplot(2,2,4); plot(tc,dc,'Color',blue,'LineWidth',1.1);
    grid on; xlabel('Time from cycle start (ms)'); ylabel('Elastic indentation (mm)');
    title('delta = max(Xbit - r, 0)');
end

f=figure('Color','w','Name','Continuous drilling advance','Position',[150 100 1100 820]);
figs(end+1,1)=f;
subplot(3,1,1); plot(t,bitAdvance*1e3,'Color',blue,'LineWidth',1.1); hold on;
plot(t,rockAdvance*1e3,'Color',orange,'LineWidth',1.1);
grid on; ylabel('Cumulative advance (mm)');
legend('Bit displacement','Permanent rock advance','Location','best');
title('Physical cumulative coordinates are retained across impacts');
subplot(3,1,2); plot(t,rockRate*1e3,'Color',green,'LineWidth',1);
grid on; ylabel('Instantaneous permanent rate (mm/s)'); xlabel('Time (s)');
subplot(3,1,3);
if hasCycle('rockAdvanceM')
    plot(cycles.impact,cycles.rockAdvanceM*1e3,'Color',orange,'Marker','.','LineWidth',1); hold on;
    if hasCycle('bitAdvanceM')
        plot(cycles.impact,cycles.bitAdvanceM*1e3,'Color',blue,'Marker','.','LineWidth',1);
        legend('Permanent rock advance','Bit advance','Location','best');
    end
    xlabel('Impact number'); ylabel('Advance per cycle (mm)'); grid on;
else
    axis off; text(.1,.5,'No complete impact cycles available.','Units','normalized');
end

if ~fixedMode && hasCycle('impact')
    f=figure('Color','w','Name','Coupled drilling cycle convergence','Position',[180 70 1100 900]);
    figs(end+1,1)=f;
    c=cycles; count=c.impact;
    subplot(4,1,1); hold on; labels={};
    residualNames={'stateResidual','periodResidual','energyResidual','advanceResidual'};
    residualLabels={'Relative state','Period','Collision energy','Permanent advance'};
    colors=[blue;green;orange;.55 .25 .65];
    for j=1:numel(residualNames)
        if hasCycle(residualNames{j})
            values=c.(residualNames{j}); values(~isfinite(values) | values<=0)=NaN;
            plot(count,values,'Color',colors(j,:),'LineWidth',1);
            labels{end+1}=residualLabels{j}; %#ok<AGROW>
        end
    end
    set(gca,'YScale','log');
    if isfield(result,'options') && isfield(result.options,'SteadyTolerance') && ~isempty(count)
        plot([min(count) max(count)],result.options.SteadyTolerance*[1 1],'k--');
        labels{end+1}='Tolerance';
    end
    grid on; ylabel('Normalized cycle change'); title(['Status: ' status]);
    if ~isempty(labels), legend(labels,'Location','best'); end
    subplot(4,1,2);
    if hasCycle('frequencyHz'), plot(count,c.frequencyHz,'Color',blue,'LineWidth',1.1); end
    grid on; ylabel('Frequency (Hz)');
    subplot(4,1,3);
    if hasCycle('relativeEnergyJ'), plot(count,c.relativeEnergyJ,'Color',orange,'LineWidth',1.1); end
    grid on; ylabel('Relative impact energy (J)');
    subplot(4,1,4);
    if hasCycle('rockAdvanceM') && hasCycle('periodS')
        rate=c.rockAdvanceM./c.periodS; rate(~isfinite(rate))=NaN;
        plot(count,rate*1e3,'Color',green,'LineWidth',1.1);
    end
    grid on; ylabel('Cycle-mean permanent rate (mm/s)'); xlabel('Impact number');
end

    function value=getDerived(name,fallback)
        if isfield(d,name) && numel(d.(name))==numel(t)
            value=d.(name); value=value(:);
        else
            value=fallback;
        end
    end

    function yes=hasCycle(name)
        yes=istable(cycles) && ~isempty(cycles) && any(strcmp(name,cycles.Properties.VariableNames));
    end

    function f=traceFigure(mask,origin,name)
        tt=(t(mask)-origin)*1e3;
        f=figure('Color','w','Name',name,'Position',[80 40 1120 870]);
        subplot(3,2,1); plot(tt,xpRel(mask)*1e3,'Color',blue,'LineWidth',1.1);
        grid on; ylabel('Piston relative position (mm)'); title(name);
        subplot(3,2,2); plot(tt,(z(mask,1)-z(1,1))*1e3,'Color',blue,'LineWidth',1.1);
        grid on; ylabel('Piston absolute advance (mm)');
        subplot(3,2,3); plot(tt,z(mask,2),'Color',blue,'LineWidth',1); hold on;
        plot(tt,z(mask,4),'Color',orange,'LineWidth',1);
        grid on; ylabel('Absolute velocity (m/s)'); legend('Piston','Tool','Location','best');
        subplot(3,2,4); plot(tt,xtRel(mask)*1e3,'Color',orange,'LineWidth',1.1);
        grid on; ylabel('Tool / buffer relative position (mm)');
        subplot(3,2,5); plot(tt,z(mask,9)*1e3,'Color',green,'LineWidth',1.1);
        grid on; ylabel('Valve relative position (mm)'); xlabel('Time from window start (ms)');
        subplot(3,2,6); plot(tt,z(mask,19)/1e6,'Color',blue,'LineWidth',1); hold on;
        plot(tt,z(mask,20)/1e6,'Color',orange,'LineWidth',1);
        grid on; ylabel('Buffer pressure (MPa gauge)'); xlabel('Time from window start (ms)');
        legend('p9','p10','Location','best');
    end
end
