function test_fixed_duration()
% MATLAB integration regression: short physical run, no plotting/files.
o=struct('MaxTime',.002,'DiscardTime',.001,'StopWhenSteady',false, ...
    'MakePlots',false,'SaveResults',false);
r=drilling_system_steady(o);
assert(strcmp(r.status,'fixed_time_complete'),r.message);
assert(abs(r.t(end)-o.MaxTime)<1e-10);
assert(~r.converged); % Fixed duration never certifies steady state.
assert(r.t(1)==0);    % DiscardTime must not delete stored transient samples.
assert(any(r.t<o.DiscardTime)&&any(r.t>=o.DiscardTime));
assert(all(isfinite(r.zSI(:))));
o.InitialStateSI=r.parameters.initialStateSI;
o.InitialStateSI(1)=o.InitialStateSI(7)+r.parameters.minPistonRel-.001;
bad=drilling_system_steady(o);
assert(strcmp(bad.status,'invalid_initial_state'));
assert(~bad.converged); % Domain failures must not become a successful fixed run.
fprintf('Fixed-duration integration checks passed.\n');
end
